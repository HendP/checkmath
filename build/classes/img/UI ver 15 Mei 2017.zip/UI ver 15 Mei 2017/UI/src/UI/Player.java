/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Serializable;
import java.util.Scanner;

public class Player implements Serializable{
    private String Nama;
    private char jawab;
    private int skor;
    private int life;

    public Player(String nama,int skor){
        this.Nama=nama;
        this.skor=skor;
    }
    public Player(){}
    
    public Player(int life){
        this.life=life;
    }
    
    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }    
    
    void set_skor(int skor){
        this.skor=skor;
        }
    
    void set_skor(){
        try{
            BufferedReader reader = new BufferedReader(new FileReader(new File("Skor.txt")));
                this.skor=Integer.parseInt(reader.readLine());
                reader.close();
        }catch(Exception ex){
            ex.printStackTrace();        
        }
    }
    
    int get_skor(){
        return this.skor;
    }
    
    void set_nama(){
        try{           
            BufferedReader reader = new BufferedReader(new FileReader(new File("Pemain.txt")));
            String line = reader.readLine();
                this.Nama=line;
                reader.close();
        }catch(Exception ex){
            ex.printStackTrace();        
    }
    }
    
    void simpan_nama(String nama){
        this.Nama=nama;
        try{
        FileWriter writer = new FileWriter("Pemain.txt");
        writer.write(nama);
        writer.close();
    }catch(Exception ex){
        ex.printStackTrace();
    }
   }
    
   String get_nama(){
       if(this.Nama==null){
           set_nama();
       }
       return this.Nama;
   }
   
   void resetskor(){
       set_skor(5);
   }
}
