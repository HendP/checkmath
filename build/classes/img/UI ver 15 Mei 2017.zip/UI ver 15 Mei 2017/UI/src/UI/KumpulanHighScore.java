/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author My PC
 */
public class KumpulanHighScore{
        private ArrayList<Player> kumpulanSD=new ArrayList<>();
        private ArrayList<Player> kumpulanSMP=new ArrayList<>();
        private ArrayList<Player> kumpulanSMA=new ArrayList<>();
        
    public void TambahHighScoreSD(Player tskor){
        BacaHighScore();        
        this.kumpulanSD.add(tskor);    
    }   
    public void TambahHighScoreSMP(Player tskor){
        BacaHighScore();
        this.kumpulanSMP.add(tskor);    
    }   
    public void TambahHighScoreSMA(Player tskor){
        BacaHighScore();
        this.kumpulanSMA.add(tskor);    
    }   
    void BacaHighScore(){
        try{
            ObjectInputStream load1 = new ObjectInputStream(new FileInputStream("SD.ser"));
            kumpulanSD.clear();
            kumpulanSD=(ArrayList<Player>)load1.readObject();
            load1.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        try{
            ObjectInputStream load2 = new ObjectInputStream(new FileInputStream("SMP.ser"));
            kumpulanSMP.clear();
            kumpulanSMP=(ArrayList<Player>)load2.readObject();
            load2.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        try{
            ObjectInputStream load = new ObjectInputStream(new FileInputStream("SMA.ser"));
            kumpulanSMA.clear();
            kumpulanSMA=(ArrayList<Player>)load.readObject();
            load.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
     ChartFrame TampilHighScore(JTable jTable1,String kelas){
            DefaultTableModel hoho=(DefaultTableModel) jTable1.getModel();
            DefaultCategoryDataset dataBar = new DefaultCategoryDataset();
            
            BacaHighScore();
            int i,j;
            String nama;
            /*SD*/
            if(kelas.equals("SD")){
            if(kumpulanSD.isEmpty()){
                JOptionPane.showMessageDialog(null, "TABEL HIGHSCORE MASIH KOSONG", "INFORMASI", JOptionPane.INFORMATION_MESSAGE);
            }else{
            if(kumpulanSD.size()<5){
            i=1;
            for(Player nilai : kumpulanSD){
                j=0;
                nama=nilai.get_nama();
                while(j<i){
                    nama=nama+' ';
                    j++;
                }
                hoho.addRow(new Object[]{i,nilai.get_nama(),nilai.get_skor()});
                dataBar.setValue(nilai.get_skor(),nama,"Nama");
                i++;              
                }
            }else{
            for(i=0;i<5;i++){
                j=0;
                hoho.addRow(new Object[]{i+1,kumpulanSD.get(i).get_nama(),kumpulanSD.get(i).get_skor()});
                nama=kumpulanSD.get(i).get_nama();
                while(j<i){
                    nama=nama+' ';
                    j++;
                }
                dataBar.setValue(kumpulanSD.get(i).get_skor(),nama,"Nama");
                }
              }
            }
            }else if(kelas.equals("SMP")){
            /*SMP*/
              if(kumpulanSMP.isEmpty()){
                JOptionPane.showMessageDialog(null, "TABEL HIGHSCORE MASIH KOSONG", "INFORMASI", JOptionPane.INFORMATION_MESSAGE);
            }else{
            if(kumpulanSMP.size()<5){
            i=1;
            for(Player nilai : kumpulanSMP){
                j=0;
                nama=nilai.get_nama();
                while(j<i){
                    nama=nama+' ';
                    j++;
                }
                hoho.addRow(new Object[]{i,nilai.get_nama(),nilai.get_skor()});
                dataBar.setValue(nilai.get_skor(),nama,"Nama");
                i++;
                }
            }else{
            for(i=0;i<5;i++){
                hoho.addRow(new Object[]{i+1,kumpulanSMP.get(i).get_nama(),kumpulanSMP.get(i).get_skor()});
                nama=kumpulanSMP.get(i).get_nama();
                j=0;
                while(j<i){
                    nama=nama+' ';
                    j++;
                }
                dataBar.setValue(kumpulanSMP.get(i).get_skor(),nama,"Nama");
                }
              }
            }
            }else{
            /*SMA*/
              if(kumpulanSMA.isEmpty()){
                JOptionPane.showMessageDialog(null, "TABEL HIGHSCORE MASIH KOSONG", "INFORMASI", JOptionPane.INFORMATION_MESSAGE);
            }else{
            if(kumpulanSMA.size()<5){
            i=1;
            for(Player nilai : kumpulanSMA){
                j=0;
                nama=nilai.get_nama();
                while(j<i){
                    nama=nama+' ';
                    j++;
                }
                hoho.addRow(new Object[]{i,nilai.get_nama(),nilai.get_skor()});
                dataBar.setValue(nilai.get_skor(),nama,"Nama");
                i++;
                }
            }else{
            for(i=0;i<5;i++){
                j=0;
                nama=kumpulanSMA.get(i).get_nama();
                hoho.addRow(new Object[]{i+1,kumpulanSMA.get(i).get_nama(),kumpulanSMA.get(i).get_skor()});
                while(j<i){
                    nama=nama+' ';
                    j++;
                }
                dataBar.setValue(kumpulanSMA.get(i).get_skor(),nama,"Nama");
                }
              }
            }
           }
            /*Chart*/
            JFreeChart chart = ChartFactory.createBarChart("GRAFIK HIGH SCORE","","",dataBar,PlotOrientation.VERTICAL,true,true,false);
            ChartFrame framechart = new ChartFrame("HIGH SCORE",chart);            
            framechart.setLocation(692, 199);
            framechart.setSize(476,424);            
            framechart.setVisible(true);
            
            return framechart;
     }
        
    void Simpan(){
        Collections.sort(kumpulanSD, (Player o1, Player o2)->((Integer)o1.get_skor()).compareTo(o2.get_skor()));
        Collections.reverse(kumpulanSD);   
        Collections.sort(kumpulanSMP, (Player o1, Player o2)->((Integer)o1.get_skor()).compareTo(o2.get_skor()));
        Collections.reverse(kumpulanSMP);   
        Collections.sort(kumpulanSMA, (Player o1, Player o2)->((Integer)o1.get_skor()).compareTo(o2.get_skor()));
        Collections.reverse(kumpulanSMA);   
        try{
            ObjectOutputStream save = new ObjectOutputStream(new FileOutputStream("SD.ser"));
            save.writeObject(kumpulanSD);
            save.close();            
        }catch(Exception ex){
            ex.printStackTrace();
            }
        try{
            ObjectOutputStream save = new ObjectOutputStream(new FileOutputStream("SMP.ser"));
            save.writeObject(kumpulanSMP);
            save.close();            
        }catch(Exception ex){
            ex.printStackTrace();
            }
        try{
            ObjectOutputStream save = new ObjectOutputStream(new FileOutputStream("SMA.ser"));
            save.writeObject(kumpulanSMA);
            save.close();            
        }catch(Exception ex){
            ex.printStackTrace();
            }
        
    }
    
    void resethighscore(){
        try{
            ObjectOutputStream save = new ObjectOutputStream(new FileOutputStream("SD.ser"));
            kumpulanSD.clear();
            save.writeObject(kumpulanSD);
            save.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        try{
            ObjectOutputStream save = new ObjectOutputStream(new FileOutputStream("SMP.ser"));
            kumpulanSMP.clear();
            save.writeObject(kumpulanSMP);
            save.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
        try{
            ObjectOutputStream save = new ObjectOutputStream(new FileOutputStream("SMA.ser"));
            kumpulanSMA.clear();
            save.writeObject(kumpulanSMA);
            save.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }    
    
    void print(){
        BacaHighScore();
        System.out.println("\n\n\nSD");
            for(Player nilai : kumpulanSD){
                System.out.println(nilai.get_nama()+"   "+nilai.get_skor());
                }
            System.out.println("\n\n\nSMP");
            for(Player nilai : kumpulanSMP){
                System.out.println(nilai.get_nama()+"   "+nilai.get_skor());
                }
            System.out.println("\n\n\nSMA");
            for(Player nilai : kumpulanSMA){
                System.out.println(nilai.get_nama()+"   "+nilai.get_skor());
                }
            System.out.println("\n\n\n");
    }
}